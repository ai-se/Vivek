import os
sdf 
os.system("python main.py main")