from log import Log
from numberlog import NumberLog

__all__ = [Log, NumberLog]
