from __future__ import division
import sys
import random
import math

from cart import *
from randomforest import *
from models import *
from searchers import *
from options import *
import time
from sk import *
import sys
sys.path.insert(0, 'defectprediction')
from main import *


sys.dont_write_bytecode = True
#Dr.M
rand=  random.random # generate nums 0..1
any=   random.choice # pull any from list
sqrt= math.sqrt  #square root function

def display(modelName,searcher,runTimes,scores,historyhi=[],historylo=[]):
  assert(len(runTimes) == len(scores)),'Ouch! it hurts'
  print "==============================================================="
  print "Model Name: %s"%modelName
  print "Searcher Name: %s"%searcher
  print "Options Used: ",
  print myoptions[searcher]
  import time
  print ("Date: %s"%time.strftime("%d/%m/%Y"))
  print "Average running time: %f " %mean(runTimes)
  if(len(historyhi)!=0):
    for x in xrange(myModelobjf[modelName]):
      print "Objective No. %d: High: %f Low: %f"%(x+1,historyhi[x],historylo[x])
  #for i in range(0,len(runTimes)):
  #  print "RunNo: %s RunTime: %s Score: %s"%(i+1,runTimes[i],scores[i])
  #print scores
  print xtile(scores,width=25,show=" %1.2f")
  print "==============================================================="

def getdata():
	from os import walk
	returnList = []
	dirs = []
	for (dirpath, dirnames, filenames) in walk("./defectprediction/data"):
	    dirs.extend(dirnames)
	    break
	#print dirs
	for dir in dirs:
		path = "./defectprediction/data/" + str(dir)
		#print path
		import os
		templst = [path +"/" + x for x in sorted(os.listdir(path))]
		assert(len(templst) >= 3 ),"Something's Wrong"
		#print =
		training = templst[-3]
		tuning = templst[-2]
		testing = templst[-1]
		#print training,tuning,testing
		returnList.append([training,tuning,testing])


	return returnList

def stats(listl):
  def median(lst,ordered=False):
    if not ordered: lst= sorted(lst)
    n = len(lst)
    p = n//2
    if n % 2: return lst[p]
    q = p - 1
    q = max(0,min(q,n))
    return (lst[p] + lst[q])/2
  from scipy.stats import scoreatpercentile
  q1 = scoreatpercentile(listl,25)
  q3 = scoreatpercentile(listl,75)  
  #print "IQR : %f"%(q3-q1)
  #print "Median: %f"%median(listl)
  return median(listl),(q3-q1)

  

def multipleRun():
   from collections import defaultdict
   r = 1
   random.seed(6)
   for f in getdata():
   	   print f
	   train = f[-3]
	   predict = f[-2]
	   test = f[-1]
	   evalScores=defaultdict(list)
	   
	   for klass in [TunedRF]:#,DTLZ5,DTLZ6,DTLZ7]:
	     print "Model Name: %s"%klass.__name__
	     
	     print ("Date: %s"%time.strftime("%d/%m/%Y"))
	     bmin = -3.2801
	     bmax = 5.6677
	     naiveWhere = []
	     print "========================TunedWhere================================"
	     print "Training : ",train
	     print "Predict: ",predict
	     print "Test: ",test
	     tstart = time.time()
	     print "Start Time: ",tstart
	     for searcher in [DE,Seive2_Initial]:
	       print "Searcher: ",searcher.__name__
	       n = 0.0
	       The.option.baseLine = False
	       The.option.tuning  = True
	       listTimeTaken = []
	       listScores = []
	       list_eval = []
	       historyhi=[-9e10 for count in xrange(myModelobjf[klass.__name__])]
	       historylo=[9e10 for count in xrange(myModelobjf[klass.__name__])]
	       print searcher.__name__,
	       for _ in range(r):
	         search = searcher(klass(train,predict),"display2",bmin,bmax)
	         #search = searcher(klass(),"display2",bmin,bmax)
	         print ".", 
	         solution,model = search.evaluate()

	       print "Time for tuning: ", time.time() - tstart
	       print "Number of Evaluation: ",model.no_eval
	       print "High Score: ",solution,scores
	       tstart = time.time()

	       tr = f[-3]
	       ts = f[-1]
	       print "Tuned Parameters: ",solution.dec
	       temp_scores = [runRF(solution.dec,tr,ts) for x in xrange(10)]
	       evalScores[searcher.__name__] = temp_scores
	       median,iqr = stats(temp_scores)
	       print "Median: ",median," IQR: ",iqr
	       print "Time for Running: ",time.time() - tstart

	   print "==========================NaiveWhere=============================="
	   #print "Baseline Finished: ",bmin,bmax
	   print "Training : ",train
	   print "Test: ",test
	   tstart = time.time()
	   print "Start Time: ",
	   temp_scores = [NaiveRF(train,test) for _ in xrange(10)]
	   evalScores['TunedRF'] = temp_scores
	   median,iqr = stats(temp_scores)
	   print "Median: ",median," IQR: ",iqr
	   print "Time for Experiment: ",time.time() - tstart
	   print evalScores
	   callrdivdemo(evalScores,"%5.0f")


def step2():
    rdivDemo([
      ["Romantic",385,214,371,627,579],
      ["Action",480,566,365,432,503],
      ["Fantasy",324,604,326,227,268],
      ["Mythology",377,288,560,368,320]])   


def callrdivdemo(eraCollector,show="%5.2f"):
  #print eraCollector
  #print "callrdivdemo %d"%len(eraCollector.keys())
  keylist = eraCollector.keys() 
  #print keylist
  variant = len(keylist)
  #print variant
  rdivarray=[]
  for y in xrange(variant):
      temp = eraCollector[keylist[y]]
      temp.insert(0,str(keylist[y]))
      rdivarray.append(temp)
  rdivDemo(rdivarray,show) 

def test():
	dictionary = [
	#ant
	{'WhereNaive': [65, 65, 65, 65, 65, 65, 65, 65, 65, 65], 
	'WhereDE': [67, 67, 67, 67, 67, 67, 67, 72, 67, 67], 
	'WhereSeive': [68, 68, 68, 68, 68, 68, 68, 68, 68, 68],
	'CartDE': [66, 61, 64, 60, 63, 64, 60, 63, 69, 60], 
	'CartNaive': [50, 52, 53, 55, 51, 51, 53, 53, 54, 53], 
	'CartSeive': [63, 60, 60, 60, 63, 60, 75, 60, 61, 60],
	'RFDE': [71, 71, 71, 72, 71, 71, 71, 71, 71, 71], 
	'RFNaive': [24, 31, 20, 26, 29, 25, 32, 29, 33, 19], 
	'RFSeive': [47, 48, 47, 47, 47, 47, 47, 47, 48, 47]
	},
	#camel
	{'WhereNaive': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
	'WhereDE': [59, 59, 59, 59, 59, 59, 59, 59, 59, 59], 
	'WhereSeive': [58, 58, 58, 58, 58, 58, 58, 58, 58, 58],
	'CartDE': [57, 63, 60, 61, 61, 64, 63, 60, 65, 59], 
	'CartNaive': [55, 52, 55, 55, 54, 56, 55, 56, 56, 55], 
	'CartSeive': [52, 51, 50, 53, 53, 52, 54, 53, 55, 56],
	'RFDE': [42, 42, 44, 43, 44, 44, 44, 40, 41, 43], 
	'RFNaive': [46, 47, 53, 49, 48, 43, 50, 46, 48, 46], 
	'RFSeive': [34, 36, 34, 36, 33, 35, 35, 34, 37, 36]
	},
	#ivy
	{'WhereNaive': [53, 53, 53, 53, 53, 53, 53, 53, 53, 54], 
	'WhereDE': [62, 62, 62, 62, 62, 62, 62, 62, 62, 62], 
	'WhereSeive': [49, 49, 49, 49, 49, 49, 49, 49, 49, 49],
	'CartDE': [77, 73, 78, 76, 76, 77, 78, 69, 69, 68], 
	'CartNaive': [60, 57, 60, 61, 62, 56, 58, 59, 58, 62], 
	'CartSeive': [75, 75, 58, 75, 75, 75, 75, 58, 58, 75],
	'RFDE': [59, 58, 50, 40, 58, 58, 58, 40, 50, 59], 
	'RFNaive': [64, 64, 70, 68, 69, 56, 66, 66, 67, 69], 
	'RFSeive': [68, 69, 70, 64, 68, 61, 69, 70, 68, 69]
	},
	#log4j
	{
	'WhereNaive': [53, 53, 53, 53, 53, 54, 53, 54, 53, 54], 
	'WhereDE': [50,50,50,50,50,54,50,50,54,54],
	'WhereSeive':[54,54,54,54,54,54,54,54,54,54],
	'CartDE': [46, 39, 34, 31, 46, 34, 22, 50, 34, 46], 
	'CartNaive': [48, 48, 47, 49, 47, 44, 50, 50, 46, 47], 
	'CartSeive': [45, 43, 49, 49, 38, 44, 36, 55, 43, 50],
	'RFDE': [38, 41, 39, 41, 37, 36, 37, 37, 37, 42], 
	'RFNaive': [33, 32, 30, 37, 33, 37, 39, 33, 27, 38], 
	'RFSeive': [26, 27, 27, 27, 26, 24, 26, 27, 27, 26]
	},
	{#lucene
	'WhereNaive': [37, 37, 37, 37, 37, 37, 37, 37, 37, 37], 
	'WhereDE': [61, 61, 61, 61, 61, 61, 61, 61, 61, 61], 
	'WhereSeive': [63, 63, 63, 63, 63, 63, 63, 63, 63, 63],
	'CartDE': [69, 61, 58, 59, 60, 66, 61, 55, 67, 65], 
	'CartNaive': [58, 54, 59, 56, 59, 59, 58, 56, 59, 57], 
	'CartSeive': [57, 56, 64, 54, 46, 53, 67, 59, 55, 53],
	'RFDE': [62, 63, 65, 64, 63, 64, 65, 63, 62, 64], 
	'RFNaive': [52, 56, 51, 58, 53, 55, 50, 54, 54, 53], 
	'RFSeive': [50, 49, 49, 49, 49, 49, 49, 49, 49, 49]
	},#poi
	{'WhereNaive': [45, 45, 45, 45, 45, 45, 45, 45, 45, 45], 
	'WhereDE': [59, 59, 60, 59, 59, 59, 60, 59, 59, 59], 
	'WhereSeive': [70, 70, 70, 70, 70, 70, 70, 70, 70, 70],
	'CartDE': [53, 51, 60, 40, 60, 53, 61, 51, 0, 54], 
	'CartNaive': [20, 21, 19, 22, 21, 23, 23, 21, 23, 23], 
	'CartSeive': [55, 58, 55, 60, 60, 46, 52, 50, 69, 56],
	'RFDE': [22, 22, 21, 22, 19, 20, 22, 21, 19, 20], 
	'RFNaive': [15, 21, 25, 11, 13, 26, 17, 20, 15, 15], 
	'RFSeive': [23, 23, 22, 22, 22, 23, 23, 23, 24, 23]

	},#velocity
	{'WhereNaive': [3, 1, 1, 3, 3, 3, 3, 3, 3, 1], 
	'WhereDE': [57, 58, 58, 57, 58, 58, 58, 58, 58, 57], 
	'WhereSeive': [31, 30, 31, 30, 31, 30, 30, 31, 30, 31],
	'CartDE': [50, 44, 59, 39, 50, 47, 54, 40, 53, 56], 
	'CartNaive': [29, 24, 26, 25, 28, 26, 27, 26, 26, 27], 
	'CartSeive': [51, 52, 28, 49, 50, 51, 58, 60, 31, 55],
	'RFDE': [15, 16, 16, 17, 15, 15, 16, 17, 15, 16], 
	'RFNaive': [15, 15, 16, 13, 14, 19, 17, 15, 16, 12], 
	'RFSeive': [13, 11, 13, 11, 11, 11, 12, 11, 12, 13]
	},#xerces
	{'WhereNaive': [37, 37, 37, 37, 37, 37, 37, 37, 37, 37], 
	'WhereDE': [48, 48, 46, 48, 46, 48, 47, 46, 46, 46], 
	'WhereSeive': [45, 45, 45, 45, 45, 45, 45, 45, 45, 45],
	'CartDE': [28, 33, 34, 25, 13, 34, 22, 31, 24, 31], 
	'CartNaive': [20, 19, 20, 19, 19, 18, 20, 19, 19, 19], 
	'CartSeive': [28, 25, 24, 10, 25, 22, 11, 12, 14, 25],
	'RFDE': [8, 11, 9, 11, 10, 10, 8, 10, 9, 9], 
	'RFNaive': [9, 8, 9, 7, 7, 10, 8, 7, 9, 7], 
	'RFSeive': [5, 5, 6, 6, 6, 7, 5, 6, 5, 5]
	}



	]
	for x in dictionary:
	  callrdivdemo(x)


if __name__ == '__main__': 
 #multipleRun()
 #step2()
 test()



