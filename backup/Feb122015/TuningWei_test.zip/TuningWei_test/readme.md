The experiment had the following conclusions

1. We can't recomment WHERE or Seive2_Initial because we are not doing good in the whole sphere.

2. Lesman's paper has been refuted by this study.

Results can be found [here](https://github.com/vivekaxl/TuningWei/blob/master/Result_WeiTuning_Conclusion.pdf).
